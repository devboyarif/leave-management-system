<template>
    currency
</template>

<script>
export default {
    layout: "Setting",
};
</script>
