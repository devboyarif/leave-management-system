<template>
    <Head :title="__('Employee Edit')"/>
    <div class="row justify-content-center">
        <div class="col-12">
            <div class="card mt-3">
                <div class="card-header">
                    <div class="d-flex justify-content-between">
                        <h3 class="card-title">{{ __('Employee Edit') }}</h3>
                        <Link :href="route('employees.index')" class="btn btn-primary">
                        <i class="fa-solid fa-arrow-left"></i>
                        {{ __('Back') }}
                        </Link>
                    </div>
                </div>
                <div class="card-body row justify-content-center">
                    <div class="col-lg-6">
                        <form @submit.prevent="updateData">
                        <div class="mb-3 row">
                           <div class="col-md-6">
                                <Label :name="__('Name')"/>
                                <input v-model="form.name" type="text" class="form-control" :class="{'is-invalid':form.errors.name}" id="name">
                                <ErrorMessage :name="form.errors.name"/>
                            </div>
                           <div class="col-md-6">
                                <Label :name="__('Email address')"/>
                                <input v-model="form.email" type="email" class="form-control" :class="{'is-invalid':form.errors.email}" id="email">
                                <ErrorMessage :name="form.errors.email"/>
                           </div>
                        </div>
                         <div class="mb-3 row">
                             <div class="col-md-6">
                                <Label :name="__('Company')"/>
                                <select @change="loadTeams" class="form-control" v-model="form.company_id" :class="{'is-invalid':form.errors.company_id}">
                                    <option value="" class="d-none">{{ __('Select Company') }}</option>
                                    <option v-for="company in companies" :key="company.id" :value="company.id">
                                        {{ company.user.name }}
                                    </option>
                                </select>
                                <ErrorMessage :name="form.errors.company_id"/>
                            </div>
                            <div class="col-md-6">
                                <Label :name="__('Team')"/>
                                <select class="form-control" v-model="form.team_id" :class="{'is-invalid':form.errors.team_id}" :disabled="!teams.length">
                                    <option value="" class="d-none">{{ __('Select Team') }}</option>
                                    <option v-for="team in teams" :key="team.id" :value="team.id">
                                        {{ team.name }}
                                    </option>
                                </select>
                                <ErrorMessage :name="form.errors.team_id"/>
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <div class="col-lg-6">
                                <Label :name="__('Change Password')" :required="false"/>
                                <input v-model="form.password" type="password" class="form-control"
                                    :class="{'is-invalid':form.errors.password}" id="password">
                                <ErrorMessage :name="form.errors.password" />
                            </div>
                             <div class="col-lg-6">
                                <Label :name="__('Phone Number')"/>
                                <vue-tel-input v-model="form.phone" mode="international"/>
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <div class="col-lg-6">
                                 <Label :name="__('Change Avatar')" :required="false"/>
                                <input accept="image/jpeg, image/jpg/ image/png" class="form-control border-0 p-0" type="file" @input="form.avatar = $event.target.files[0]" :class="{'is-invalid':form.errors.avatar}"/>
                                <ErrorMessage :name="form.errors.avatar"/>
                            </div>
                        </div>
                        <button :disabled="form.processing" type="submit" class="btn btn-primary">
                            <Loading v-if="form.processing"/>
                            <span v-else>
                                <i class="fa-solid fa-check mr-1"></i>
                                {{ __('Save') }}
                            </span>
                        </button>
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import { Inertia } from "@inertiajs/inertia";
import { VueTelInput } from 'vue-tel-input';
import 'vue-tel-input/dist/vue-tel-input.css';

export default {
    props: {
        companies: {
            type: Array,
            required: true,
        },
        user: {
            type: Object,
            required: true,
        },
        employee: {
            type: Object,
            required: true,
        },
        teams: {
            type: Array,
            required: true,
        },
    },
    components: {
        Inertia,
        VueTelInput
    },
    data() {
        return {
            form: this.$inertia.form({
                name: this.user.name,
                email: this.user.email,
                password: null,
                avatar: null,
                company_id: this.employee.company_id,
                team_id: this.employee.team_id,
                phone: this.employee.phone,
                _method: "PUT",
            }),
            companies: this.companies,
            teams: this.teams,
        };
    },
    methods: {
        updateData() {
            this.form.post(route("employees.update", this.employee.id));
        },
        async loadTeams() {
            this.teams = [];
            let response = await axios.get(
                route("companies.teams", this.form.company_id)
            );
            this.teams = response.data.teams;
        },
    },
     mounted(){
        this.checkPagePermission('admin')
    }
};
</script>
