<template>
    seo
</template>

<script>
export default {
    layout: "Setting",
};
</script>
