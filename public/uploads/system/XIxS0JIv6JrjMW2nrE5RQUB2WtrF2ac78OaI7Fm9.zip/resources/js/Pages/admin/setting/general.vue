<template>
    general
</template>

<script>
export default {
    layout: 'Setting'
}
</script>
