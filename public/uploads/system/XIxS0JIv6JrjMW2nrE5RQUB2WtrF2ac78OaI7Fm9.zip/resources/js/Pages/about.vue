<template>
    <Head title="About"/>

    <div class="row">
       <div class="col-6">
            About Page
       </div>
    </div>
</template>
